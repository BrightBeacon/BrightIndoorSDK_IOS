//
//  BLELocationEngineConstants
//  BLEProject
//
//  Created by innerpeacer on 15/2/2.
//  Copyright (c) 2015年 innerpeacer. All rights reserved.
//

#ifndef BLELocationEngineConstants_h
#define BLELocationEngineConstants_h

#define PI 3.1415926
#define CONSTANT_HUNDRED_THROUSAND 100000

#endif
